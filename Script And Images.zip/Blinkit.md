# Blinkit


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')
from matplotlib.gridspec import GridSpec
```


```python
customer_feedback=pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_customer_feedback.csv")
customers = pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_customers.csv")
delivery_performance = pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_delivery_performance.csv")
inventory = pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_inventory.csv")
inventory_New = pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_inventoryNew.csv")
marketing_performance = pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_marketing_performance.csv")
order_items = pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_order_items.csv")
orders = pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_orders.csv")
products = pd.read_csv(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\blinkit_products.csv")
category_icon = pd.read_excel(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\Category_Icons.xlsx")
rating_icon = pd.read_excel(r"C:\Users\Vinay Raykar\OneDrive\Documents\My Courses\Cyber Success DA & DS\All projects\Blinkit project\Blink-it data\Rating_Icon.xlsx")

```


```python
# Data Cleaning.

# Changing Datatype of C feedback table
customer_feedback["feedback_date"] = customer_feedback["feedback_date"].astype('datetime64[ns]')

# Changing Datatype of Customers table
customers["phone"] = customers["phone"].astype('int64')
customers["registration_date"] = customers["registration_date"].astype('datetime64[ns]')

#Changing Datatype of DP table
delivery_performance["promised_time"] = delivery_performance["promised_time"].astype('datetime64[ns]')
delivery_performance["actual_time"] = delivery_performance["actual_time"].astype('datetime64[ns]')

# Changing Datatype of Inventory table
inventory["date"] = inventory["date"].astype('datetime64[ns]')
inventory.dropna(inplace = True)

#Changing Datatype of INewtable
inventory_New["date"] = inventory_New["date"].astype('datetime64[ns]')

# Changing Datatype of MP table
marketing_performance["date"] = marketing_performance["date"].astype('datetime64[ns]')

#Changing Datatype of Orders table
orders["order_date"] = orders["order_date"].astype('datetime64[ns]')
orders["promised_delivery_time"] = orders["promised_delivery_time"].astype('datetime64[ns]')
orders["actual_delivery_time"] = orders["actual_delivery_time"].astype('datetime64[ns]')

#Changing Datatype of category Icon table
"""category_icon.drop(columns = ['Unnamed: 2','Unnamed: 3','Unnamed: 4','Unnamed: 5','Unnamed: 6','Unnamed: 7','Unnamed: 8','Unnamed: 9'], axis = 1, inplace = True)"""
```




    "category_icon.drop(columns = ['Unnamed: 2','Unnamed: 3','Unnamed: 4','Unnamed: 5','Unnamed: 6','Unnamed: 7','Unnamed: 8','Unnamed: 9'], axis = 1, inplace = True)"




```python
delivery_performance.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>delivery_partner_id</th>
      <th>promised_time</th>
      <th>actual_time</th>
      <th>delivery_time_minutes</th>
      <th>distance_km</th>
      <th>delivery_status</th>
      <th>reasons_if_delayed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1549769649</td>
      <td>14983</td>
      <td>2024-05-28 13:25:00</td>
      <td>2024-05-28 13:27:00</td>
      <td>2</td>
      <td>0.98</td>
      <td>On Time</td>
      <td>Traffic</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9185164487</td>
      <td>39859</td>
      <td>2024-09-23 13:25:00</td>
      <td>2024-09-23 13:29:00</td>
      <td>4</td>
      <td>3.83</td>
      <td>On Time</td>
      <td>Traffic</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5427684290</td>
      <td>84315</td>
      <td>2023-11-20 05:17:00</td>
      <td>2023-11-20 05:18:00</td>
      <td>1</td>
      <td>2.63</td>
      <td>On Time</td>
      <td>Traffic</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4898355547</td>
      <td>14630</td>
      <td>2023-04-16 19:01:00</td>
      <td>2023-04-16 19:02:00</td>
      <td>1</td>
      <td>2.20</td>
      <td>On Time</td>
      <td>Traffic</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6568151549</td>
      <td>67714</td>
      <td>2024-03-31 06:37:00</td>
      <td>2024-03-31 06:39:00</td>
      <td>2</td>
      <td>1.30</td>
      <td>On Time</td>
      <td>Traffic</td>
    </tr>
  </tbody>
</table>
</div>




```python
delivery_performance.dtypes
```




    order_id                          int64
    delivery_partner_id               int64
    promised_time            datetime64[ns]
    actual_time              datetime64[ns]
    delivery_time_minutes             int64
    distance_km                     float64
    delivery_status                  object
    reasons_if_delayed               object
    dtype: object




```python
delivery_performance.isnull().sum()
```




    order_id                 0
    delivery_partner_id      0
    promised_time            0
    actual_time              0
    delivery_time_minutes    0
    distance_km              0
    delivery_status          0
    reasons_if_delayed       0
    dtype: int64




```python
customers.shape
```




    (2500, 11)




```python
delivery_performance.columns.value_counts()
```




    order_id                 1
    delivery_partner_id      1
    promised_time            1
    actual_time              1
    delivery_time_minutes    1
    distance_km              1
    delivery_status          1
    reasons_if_delayed       1
    Name: count, dtype: int64




```python
inventory.dtypes
```




    product_id                 int64
    date              datetime64[ns]
    stock_received             int64
    damaged_stock              int64
    dtype: object




```python
orders['order_date'].head()
```




    0   2024-07-17 08:34:00
    1   2024-05-28 13:14:00
    2   2024-09-23 13:07:00
    3   2023-11-24 16:16:00
    4   2023-11-20 05:00:00
    Name: order_date, dtype: datetime64[ns]




```python
# reference_date
```


```python

```

**1. Who are Blinkit's most valuable customers?**

 Segment customers based on frequency, monetary value, and recency (RFM analysis).
 Identify which city or segment is the most profitable.


```python
# valuable=order[["customer_id"]["order_total"].count()]
```


```python
# Reference date = one day after latest order
reference_date = orders['order_date'].max() + pd.Timedelta(days=1)

# Group by customer and calculate RFM metrics
rfm = orders.groupby('customer_id').agg({
    'order_date': lambda x: (reference_date - x.max()).days,  # Recency
    'order_id': 'count',                                      # Frequency
    'order_total': 'sum'                                      # Monetary
}).reset_index()

rfm.columns = ['customer_id', 'Recency', 'Frequency', 'Monetary']

# Score each R, F, M from 1 (low) to 4 (high)
rfm['R_Score'] = pd.qcut(rfm['Recency'], 4, labels=[4, 3, 2, 1]).astype(int)
rfm['F_Score'] = pd.qcut(rfm['Frequency'].rank(method='first'), 4, labels=[1, 2, 3, 4]).astype(int)
rfm['M_Score'] = pd.qcut(rfm['Monetary'], 4, labels=[1, 2, 3, 4]).astype(int)

# Combine scores
rfm['RFM_Score'] = rfm[['R_Score', 'F_Score', 'M_Score']].sum(axis = 1)
rfm['RFM_Segment'] = rfm['R_Score'].astype(str) + rfm['F_Score'].astype(str) + rfm['M_Score'].astype(str)

# Merge with customer data
rfm = rfm.merge(customers[['customer_id', 'area', 'customer_segment']], on='customer_id', how='left')
```


```python
rfm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>Recency</th>
      <th>Frequency</th>
      <th>Monetary</th>
      <th>R_Score</th>
      <th>F_Score</th>
      <th>M_Score</th>
      <th>RFM_Score</th>
      <th>RFM_Segment</th>
      <th>area</th>
      <th>customer_segment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>31813</td>
      <td>26</td>
      <td>2</td>
      <td>5726.04</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>9</td>
      <td>423</td>
      <td>Sultan Pur Majra</td>
      <td>Regular</td>
    </tr>
    <tr>
      <th>1</th>
      <td>61020</td>
      <td>66</td>
      <td>3</td>
      <td>7844.90</td>
      <td>4</td>
      <td>3</td>
      <td>4</td>
      <td>11</td>
      <td>434</td>
      <td>Kurnool</td>
      <td>New</td>
    </tr>
    <tr>
      <th>2</th>
      <td>119099</td>
      <td>165</td>
      <td>4</td>
      <td>14768.77</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>11</td>
      <td>344</td>
      <td>Kavali</td>
      <td>Inactive</td>
    </tr>
    <tr>
      <th>3</th>
      <td>188838</td>
      <td>260</td>
      <td>2</td>
      <td>5182.04</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>7</td>
      <td>223</td>
      <td>Madanapalle</td>
      <td>Inactive</td>
    </tr>
    <tr>
      <th>4</th>
      <td>191616</td>
      <td>165</td>
      <td>2</td>
      <td>4089.96</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>7</td>
      <td>322</td>
      <td>Pallavaram</td>
      <td>Regular</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig = plt.figure(figsize = (15,7))
gs = plt.GridSpec(2,2, width_ratios = [1,2])
                 
# Plot 1
ax1 = plt.subplot(gs[:,0])
sns.countplot(data=rfm, x='customer_segment', order=rfm['customer_segment'].value_counts().index,edgecolor = 'k', linewidth = 2, palette="viridis")
ax1.set_title("Customer Segment Distribution in RFM Top Customers")
ax1.set_ylabel("Number of Customers")
ax1.set_xlabel("Customer Segment")
plt.xticks(rotation=35)


# Plot 2
top_customers = rfm[rfm['RFM_Score'] == 12]
top_areas = top_customers['area'].value_counts().nlargest(10)


ax2 = plt.subplot(gs[:, 1])
sns.barplot(x=top_areas.values, y=top_areas.index, palette='magma')
ax2.set_title("Top Areas with Most Valuable Customers")
ax2.set_xlabel("Number of Top Customers (RFM Score = 12)")
ax2.set_ylabel("Area/ Zone")


plt.tight_layout()
plt.show()
```


    
![png](output_17_0.png)
    


**2. Who are the common trends in customer purchase behaviour?**

Analyze peak ordering times (hour, day of week).
Identify popular product categories by volume and revenue.


```python
pop_cat = products.groupby('category').agg({'product_id':'count', 'price':'sum'})
pop_cat = pop_cat.rename(columns = {'product_id':'Volume','price':'Total_Price'})
```


```python
# Extract hour and day of week for peak time analysis
orders['order_hour'] = orders['order_date'].dt.hour
orders['order_day'] = orders['order_date'].dt.day_name()

# Peak ordering times: count of orders by hour and day
peak_hour = orders.groupby('order_hour').size().reset_index(name='order_count')
peak_day = orders.groupby('order_day').size().reset_index(name='order_count')
peak_day['order_day'] = pd.Categorical(peak_day['order_day'], categories=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'], ordered=True)
peak_day = peak_day.sort_values('order_day')

# Merge order items with products to get categories
order_details = pd.merge(order_items, products[['product_id', 'category']], on='product_id', how='left')

# Calculate revenue per order item (quantity * unitprice)
order_details['item_revenue'] = order_details['quantity'] * order_details['unit_price']

# Aggregate by category for volume and revenue
pop_categories = order_details.groupby('category').agg({'product_id':'count', 'item_revenue':'sum'}).reset_index()
pop_categories = pop_categories.rename(columns={'product_id':'Volume', 'item_revenue':'Total_Revenue'})

# Sorting By Revenue
pop_categories = pop_categories.sort_values( by = 'Total_Revenue', ascending = False).reset_index()
```


```python
pop_categories
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>category</th>
      <th>Volume</th>
      <th>Total_Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>Dairy &amp; Breakfast</td>
      <td>566</td>
      <td>639222.19</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9</td>
      <td>Pharmacy</td>
      <td>481</td>
      <td>592368.57</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Fruits &amp; Vegetables</td>
      <td>492</td>
      <td>559053.08</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8</td>
      <td>Pet Care</td>
      <td>501</td>
      <td>539888.75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Household Care</td>
      <td>509</td>
      <td>444244.25</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7</td>
      <td>Personal Care</td>
      <td>454</td>
      <td>394894.61</td>
    </tr>
    <tr>
      <th>6</th>
      <td>10</td>
      <td>Snacks &amp; Munchies</td>
      <td>483</td>
      <td>394648.71</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>Cold Drinks &amp; Juices</td>
      <td>375</td>
      <td>392717.62</td>
    </tr>
    <tr>
      <th>8</th>
      <td>4</td>
      <td>Grocery &amp; Staples</td>
      <td>449</td>
      <td>359937.82</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0</td>
      <td>Baby Care</td>
      <td>334</td>
      <td>348227.18</td>
    </tr>
    <tr>
      <th>10</th>
      <td>6</td>
      <td>Instant &amp; Frozen Food</td>
      <td>356</td>
      <td>307212.65</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(12,5))
sns.lineplot(data = pop_categories, x = pop_categories["Volume"], y = pop_categories["Total_Revenue"], marker="o", mfc="yellow",markeredgecolor ='k', c="darkcyan",linewidth=2, ms= 7)

plt.xlabel("Volume", fontweight = 'bold', fontsize = 10)
plt.ylabel("Total Revenue", fontweight = 'bold', fontsize = 10)
plt.title("Total Sales By Volume", fontweight = 'bold', fontsize = 14)

plt.grid()
plt.show()
```


    
![png](output_22_0.png)
    


**• Delivery Performance Analysis**

**3. What percentage of deliveries are delayed, and which locations or delivery partners are responsible?**

 Analyze late vs. on time deliveries by city, partner, and product.



```python
# Table Merged
dp_orders = pd.merge(delivery_performance[['order_id', 'delivery_partner_id', 'delivery_status', 'reasons_if_delayed']], orders[['order_id', 'customer_id', 'delivery_status', 'order_total', 'delivery_partner_id']], on ='delivery_partner_id', how = 'inner')
dp_o_c = pd.merge(dp_orders, customers[['customer_id', 'customer_name', 'area', 'pincode','customer_segment', 'total_orders']], on = 'customer_id', how = 'inner')

# 
total = len(delivery_performance)
delayed = delivery_performance['delivery_status'].str.lower().str.contains('delayed', 'late').sum()

# Overall delayed Percentage
overall_delayed = delayed / total  * 100

# percentage by city
pct_city = dp_o_c.groupby('area')['delivery_status_x'].apply(lambda x: x.str.lower().str.contains('delayed').mean() * 100).reset_index(name = 'Delay%')

# percentage by delivery man
delivery_delayed = dp_o_c.groupby('delivery_partner_id')['delivery_status_x'].apply(lambda x: x.str.lower().str.contains('delayed').mean() * 100).reset_index(name = 'Delay%')

print("Total Percentage of deliveries are delayed by",round(overall_delayed,2),"%")
```

    Total Percentage of deliveries are delayed by 49.39 %
    


```python
# df1 = pd.DataFrame(pct_city)
# df2 = pd.DataFrame(delivery_delayed)
# df2 = pd.merge(df1, df2
# df2
```


```python
print("Total Percentage of deliveries delayed of city is")
round(pct_city,2).head()
```

    Total Percentage of deliveries delayed of city is
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>area</th>
      <th>Delay%</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adoni</td>
      <td>63.64</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Agartala</td>
      <td>66.67</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Agra</td>
      <td>66.67</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Ahmedabad</td>
      <td>50.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Ahmednagar</td>
      <td>36.84</td>
    </tr>
  </tbody>
</table>
</div>




```python
print("Total Percentage of deliveries delayed of Delivery Man is")
round(delivery_delayed,2).head()
```

    Total Percentage of deliveries delayed of Delivery Man is
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>delivery_partner_id</th>
      <th>Delay%</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>43</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>66</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>70</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>102</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>158</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plot percentage of deliveries delayed by city
plt.figure(figsize=(10,6))
rank = sns.barplot(data=pct_city.head(10), x='area', y='Delay%', edgecolor = 'k', linewidth = 2, color = 'olivedrab')
plt.xticks(rotation=40)
plt.title('Percentage of Deliveries Delayed by City')
plt.ylabel('Delay Percentage %')
plt.xlabel('City/Area')

for bar in rank.containers:
    rank.bar_label(bar)


plt.tight_layout()
plt.show()
```


    
![png](output_29_0.png)
    


**4. How do delivery times affect customer feedback or repeat orders?**

 Correlate delivery time and rating/comments/retention.


```python
# corr od Rating
dp_cf = pd.merge(delivery_performance,customer_feedback, on = 'order_id', how = 'inner')
corr_rating = dp_cf['actual_time'].corr(dp_cf['rating'])


# Analyze the feedback comments by delivery speed
fast_delivery_comm = dp_cf[dp_cf['actual_time'] < dp_cf['actual_time'].median()]['feedback_text']
slow_delivery_comm = dp_cf[dp_cf['actual_time'] >= dp_cf['actual_time'].median()]['feedback_text']

# find negative words for feedback comments at late delivery.
neg_words = ['delay','late','slow','wait']
slow_neg_comm = slow_delivery_comm.str.lower().str.contains('|'.join(neg_words)).sum()
comment_rating = slow_neg_comm / len(slow_delivery_comm)

# count the total order in order's table
customer_order = orders.groupby('customer_id').size().reset_index(name = 'order_count')
# merge table
dp_cf_o = pd.merge(dp_cf, orders[['order_id','customer_id']], on = ['order_id','customer_id'], how = 'left')
dp_cf_o = pd.merge(dp_cf_o, customer_order, on = 'customer_id', how = 'left')
corr_reten = dp_cf_o['actual_time'].corr(dp_cf_o['order_count'])

print('Correlation between delivery time and rating:', corr_rating)
print('Slow delivery negative comment rate:', comment_rating)
print('Correlation between delivery time and repeat orders:', corr_reten)
```

    Correlation between delivery time and rating: 0.00388869819964741
    Slow delivery negative comment rate: 0.028405422853453842
    Correlation between delivery time and repeat orders: 0.00014315882771442773
    


```python
dp_cf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>delivery_partner_id</th>
      <th>promised_time</th>
      <th>actual_time</th>
      <th>delivery_time_minutes</th>
      <th>distance_km</th>
      <th>delivery_status</th>
      <th>reasons_if_delayed</th>
      <th>feedback_id</th>
      <th>customer_id</th>
      <th>rating</th>
      <th>feedback_text</th>
      <th>feedback_category</th>
      <th>sentiment</th>
      <th>feedback_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1549769649</td>
      <td>14983</td>
      <td>2024-05-28 13:25:00</td>
      <td>2024-05-28 13:27:00</td>
      <td>2</td>
      <td>0.98</td>
      <td>On Time</td>
      <td>Traffic</td>
      <td>5450964</td>
      <td>9573071</td>
      <td>3</td>
      <td>The order was incorrect.</td>
      <td>App Experience</td>
      <td>Negative</td>
      <td>2024-05-28</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9185164487</td>
      <td>39859</td>
      <td>2024-09-23 13:25:00</td>
      <td>2024-09-23 13:29:00</td>
      <td>4</td>
      <td>3.83</td>
      <td>On Time</td>
      <td>Traffic</td>
      <td>482108</td>
      <td>45477575</td>
      <td>3</td>
      <td>It was okay, nothing special.</td>
      <td>App Experience</td>
      <td>Neutral</td>
      <td>2024-09-23</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5427684290</td>
      <td>84315</td>
      <td>2023-11-20 05:17:00</td>
      <td>2023-11-20 05:18:00</td>
      <td>1</td>
      <td>2.63</td>
      <td>On Time</td>
      <td>Traffic</td>
      <td>3537464</td>
      <td>83298567</td>
      <td>3</td>
      <td>Product was damaged during delivery.</td>
      <td>Delivery</td>
      <td>Negative</td>
      <td>2023-11-20</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4898355547</td>
      <td>14630</td>
      <td>2023-04-16 19:01:00</td>
      <td>2023-04-16 19:02:00</td>
      <td>1</td>
      <td>2.20</td>
      <td>On Time</td>
      <td>Traffic</td>
      <td>230696</td>
      <td>13284996</td>
      <td>4</td>
      <td>Highly recommended!</td>
      <td>Product Quality</td>
      <td>Positive</td>
      <td>2023-04-16</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6568151549</td>
      <td>67714</td>
      <td>2024-03-31 06:37:00</td>
      <td>2024-03-31 06:39:00</td>
      <td>2</td>
      <td>1.30</td>
      <td>On Time</td>
      <td>Traffic</td>
      <td>2259308</td>
      <td>88866835</td>
      <td>2</td>
      <td>I had a bad experience.</td>
      <td>App Experience</td>
      <td>Negative</td>
      <td>2024-03-31</td>
    </tr>
  </tbody>
</table>
</div>



**• Inventory Optimization**

**5. Which products frequently go out of stock or have excess inventory?**

 Detect stockouts or overstock patterns by warehouse or product.


```python
# inv_prod.head()
```


```python
inv_prod = pd.merge(inventory, products, on = 'product_id', how = 'left')
summary_stock_low = inv_prod.pivot_table(values = 'min_stock_level', index = 'product_name', aggfunc = 'mean')
summary_stock_high = inv_prod.pivot_table(values = 'max_stock_level', index = 'product_name', aggfunc = 'mean')
Overall_summary_stock = pd.merge(summary_stock_low,summary_stock_high, on = 'product_name', how = 'outer')

Overall_summary_stock = Overall_summary_stock.round(2).reset_index().head(10)
Overall_summary_stock
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_name</th>
      <th>min_stock_level</th>
      <th>max_stock_level</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Baby Food</td>
      <td>14.65</td>
      <td>71.67</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Baby Wipes</td>
      <td>20.75</td>
      <td>77.43</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bananas</td>
      <td>20.76</td>
      <td>88.22</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Biscuits</td>
      <td>19.57</td>
      <td>73.21</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bread</td>
      <td>21.58</td>
      <td>78.20</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Butter</td>
      <td>22.92</td>
      <td>73.86</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Carrots</td>
      <td>24.52</td>
      <td>74.70</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Cat Food</td>
      <td>22.80</td>
      <td>86.89</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Cereal</td>
      <td>25.50</td>
      <td>77.97</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Cheese</td>
      <td>19.13</td>
      <td>81.14</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(12,7))

x = np.arange(len(Overall_summary_stock['product_name']))


width = 0.35
plt.bar(x - width/2,  Overall_summary_stock['min_stock_level'],width, label = "Min Stock", edgecolor = 'k', linewidth = 2, color = 'teal')
plt.bar(x + width/2, Overall_summary_stock['max_stock_level'],width, label = 'Max Stock', edgecolor = 'k', linewidth = 2, color = 'olive')


plt.title('Min vs Max Stock Levels by Product (Top 10)', fontweight = "bold", fontsize = 14)
plt.ylabel('Stock Level', fontweight = "bold", fontsize = 10)
plt.xlabel('Product Name', fontweight = "bold", fontsize = 10)
plt.xticks(x,Overall_summary_stock['product_name'], rotation = 30, ha = 'right')
plt.legend()


plt.tight_layout()
plt.show()
```


    
![png](output_36_0.png)
    


**6. Top selling products always available across locations?**

 Crosscheck demand vs. stock availability


```python
# Merging 3 table for connecting their columns
oi_o = pd.merge(order_items, orders[['customer_id','order_id']], on = 'order_id' , how = 'inner')
oi_o_p = pd.merge(products[['product_id', 'product_name', 'category', 'min_stock_level', 'max_stock_level']],oi_o, on = 'product_id' , how = 'inner')
oi_o_p_c = pd.merge(oi_o_p, customers[['customer_id','area','total_orders','avg_order_value']], on = 'customer_id' , how = 'inner')

# Pivot table for finding out top selling products by location
top_sell = oi_o_p_c.pivot_table(values = 'unit_price', index = ['product_name','area'], aggfunc = "sum", margins = True)
top_sell = top_sell.sort_values(by = 'unit_price', ascending = False).head(10)
top_sell
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>unit_price</th>
    </tr>
    <tr>
      <th>product_name</th>
      <th>area</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>All</th>
      <th></th>
      <td>2465789.50</td>
    </tr>
    <tr>
      <th>Toilet Cleaner</th>
      <th>Gandhinagar</th>
      <td>4176.33</td>
    </tr>
    <tr>
      <th>Pet Treats</th>
      <th>Gandhinagar</th>
      <td>2992.10</td>
    </tr>
    <tr>
      <th>Lotion</th>
      <th>Machilipatnam</th>
      <td>2823.32</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">Vitamins</th>
      <th>Kamarhati</th>
      <td>2809.97</td>
    </tr>
    <tr>
      <th>Nizamabad</th>
      <td>2740.16</td>
    </tr>
    <tr>
      <th>Dish Soap</th>
      <th>Rajkot</th>
      <td>2693.54</td>
    </tr>
    <tr>
      <th>Cola</th>
      <th>Etawah</th>
      <td>2692.58</td>
    </tr>
    <tr>
      <th>Dog Food</th>
      <th>Sambalpur</th>
      <td>2622.35</td>
    </tr>
    <tr>
      <th>Bread</th>
      <th>Ahmednagar</th>
      <td>2620.79</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize = (12,8))

sns.heatmap(top_sell, annot = True, fmt = '0.2f', cmap = 'viridis', linewidth = 0.5)

plt.title('HeatMap for Top selling products', fontweight = "bold", fontsize = 14)
plt.ylabel('Product Name and Area', fontweight = "bold", fontsize = 10)
plt.xlabel('Unit Price', fontweight = "bold", fontsize = 10)

plt.tight_layout()
plt.show()
```


    
![png](output_39_0.png)
    


**• Marketing Performance**

**7. Which marketing channels or campaigns bring the most high value customers?**

 Analyze cost vs. revenue per campaign.



```python
marketing_performance['roas'] = marketing_performance['revenue_generated'] / marketing_performance['spend']
valuable_cust = marketing_performance.groupby(['channel', 'campaign_name'])['roas'].mean().sort_values(ascending = False).reset_index()

print(f'The Channel "{valuable_cust['channel'][0]}" and the Campaign Name "{valuable_cust['campaign_name'][0]}" bring the most high value customers.')
valuable_cust = valuable_cust.head(10)
valuable_cust

# Group by channel
channel = valuable_cust.groupby('channel')['roas'].sum().reset_index()
channel
```

    The Channel "Email" and the Campaign Name "Referral Program" bring the most high value customers.
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>channel</th>
      <th>roas</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Email</td>
      <td>15.555027</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SMS</td>
      <td>4.963909</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Social Media</td>
      <td>5.214550</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig = plt.figure(figsize=(16,7))
gs = plt.GridSpec(2,2)


# PLot 1 Horizontal Bar
ax1 = plt.subplot(gs[:, 0])
sns.barplot(data = valuable_cust, x = valuable_cust['roas'], y = valuable_cust['campaign_name'], edgecolor = 'k', linewidth = 2, color = 'brown', errorbar = None)

ax1.set_title('Marketing campaigns bring the most high value customers', fontweight = "bold", fontsize = 14)
ax1.set_xlabel('Roas', fontweight = "bold", fontsize = 10)
ax1.set_ylabel('Campaig Name', fontweight = "bold", fontsize = 10)


# PLot 2 PIE
ax2 = plt.subplot(gs[:,1])
plt.pie(channel['roas'], autopct = "%1.1f%%", startangle = 90, shadow = True, colors = ['goldenrod','royalblue','seagreen'], explode = [0.0,0.0,0.0])
ax2.set_title('Marketing channels bring the most high value customers', fontweight = "bold", fontsize = 14)
ax2.legend(labels = channel['channel'], loc = 'lower right', fontsize = 11)

plt.tight_layout()
plt.show()
```


    
![png](output_42_0.png)
    


**8. What is the ROI of marketing campaigns across cities?**

Compare spend and conversion metrics geographically.



```python
marketing_performance.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>campaign_id</th>
      <th>campaign_name</th>
      <th>date</th>
      <th>target_audience</th>
      <th>channel</th>
      <th>impressions</th>
      <th>clicks</th>
      <th>conversions</th>
      <th>spend</th>
      <th>revenue_generated</th>
      <th>roas</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>548299</td>
      <td>New User Discount</td>
      <td>2024-11-05</td>
      <td>Premium</td>
      <td>App</td>
      <td>3130</td>
      <td>163</td>
      <td>78</td>
      <td>1431.85</td>
      <td>4777.75</td>
      <td>3.336767</td>
    </tr>
    <tr>
      <th>1</th>
      <td>390914</td>
      <td>Weekend Special</td>
      <td>2024-11-05</td>
      <td>Inactive</td>
      <td>App</td>
      <td>3925</td>
      <td>494</td>
      <td>45</td>
      <td>4506.34</td>
      <td>6238.11</td>
      <td>1.384296</td>
    </tr>
    <tr>
      <th>2</th>
      <td>834385</td>
      <td>Festival Offer</td>
      <td>2024-11-05</td>
      <td>Inactive</td>
      <td>Email</td>
      <td>7012</td>
      <td>370</td>
      <td>78</td>
      <td>4524.23</td>
      <td>2621.00</td>
      <td>0.579325</td>
    </tr>
    <tr>
      <th>3</th>
      <td>241523</td>
      <td>Flash Sale</td>
      <td>2024-11-05</td>
      <td>Inactive</td>
      <td>SMS</td>
      <td>1115</td>
      <td>579</td>
      <td>86</td>
      <td>3622.79</td>
      <td>2955.00</td>
      <td>0.815670</td>
    </tr>
    <tr>
      <th>4</th>
      <td>595111</td>
      <td>Membership Drive</td>
      <td>2024-11-05</td>
      <td>New Users</td>
      <td>Email</td>
      <td>7172</td>
      <td>795</td>
      <td>54</td>
      <td>2888.99</td>
      <td>8951.81</td>
      <td>3.098595</td>
    </tr>
  </tbody>
</table>
</div>




```python
marketing_performance['ROI (%)'] = ((marketing_performance['revenue_generated'] - marketing_performance['spend']) / marketing_performance['spend']) * 100
mp_ct = pd.merge(marketing_performance, customers[['customer_id','customer_name','area','customer_segment','total_orders','avg_order_value']], left_on = 'target_audience', right_on = 'customer_segment', how = 'left')
ROI_city = mp_ct.groupby('area')['ROI (%)'].mean().reset_index()
ROI_city = ROI_city.head(10).round(3)
ROI_city
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>area</th>
      <th>ROI (%)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adoni</td>
      <td>139.975</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Agartala</td>
      <td>138.379</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Agra</td>
      <td>138.151</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Ahmedabad</td>
      <td>137.243</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Ahmednagar</td>
      <td>139.844</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Aizawl</td>
      <td>137.243</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Ajmer</td>
      <td>137.243</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Akola</td>
      <td>140.279</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Alappuzha</td>
      <td>137.243</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Aligarh</td>
      <td>141.807</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(12,6))

sns.barplot(x='ROI (%)', y='area', data=ROI_city, palette='coolwarm', edgecolor = 'k')
plt.title('Average ROI by City', fontweight='bold', fontsize=14)
plt.xlabel('Average ROI (%)')
plt.ylabel('City/Area')

plt.tight_layout()
plt.show()

```


    
![png](output_46_0.png)
    



```python

```

**• Customer Feedback Insights**

**9. What are the top issues mentioned by customers in feedback?**

 Perform text analysis/sentiment analysis on reviews.


```python
top_issues = customer_feedback[(customer_feedback['sentiment'] == 'Negative') & 
            (customer_feedback['feedback_text'].notnull()) & 
            (customer_feedback['feedback_text'].str.strip != '')].sort_values(by = 'rating', ascending = True).head(20)
top_issues
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>feedback_id</th>
      <th>order_id</th>
      <th>customer_id</th>
      <th>rating</th>
      <th>feedback_text</th>
      <th>feedback_category</th>
      <th>sentiment</th>
      <th>feedback_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1812</th>
      <td>8638304</td>
      <td>9664390656</td>
      <td>16420489</td>
      <td>1</td>
      <td>Delivery was late and I was unhappy.</td>
      <td>Product Quality</td>
      <td>Negative</td>
      <td>2023-08-09</td>
    </tr>
    <tr>
      <th>1823</th>
      <td>8551149</td>
      <td>3242700095</td>
      <td>84468124</td>
      <td>1</td>
      <td>Taste was not as expected.</td>
      <td>Customer Service</td>
      <td>Negative</td>
      <td>2024-10-14</td>
    </tr>
    <tr>
      <th>1830</th>
      <td>8655854</td>
      <td>8318806722</td>
      <td>67696145</td>
      <td>1</td>
      <td>The packaging was poor.</td>
      <td>Delivery</td>
      <td>Negative</td>
      <td>2024-07-25</td>
    </tr>
    <tr>
      <th>1843</th>
      <td>6873205</td>
      <td>2006434350</td>
      <td>20956158</td>
      <td>1</td>
      <td>The order was incorrect.</td>
      <td>Customer Service</td>
      <td>Negative</td>
      <td>2023-06-24</td>
    </tr>
    <tr>
      <th>1877</th>
      <td>3303179</td>
      <td>3187042843</td>
      <td>8651281</td>
      <td>1</td>
      <td>Delivery was late and I was unhappy.</td>
      <td>Product Quality</td>
      <td>Negative</td>
      <td>2024-01-01</td>
    </tr>
    <tr>
      <th>1879</th>
      <td>7174582</td>
      <td>881900445</td>
      <td>34567918</td>
      <td>1</td>
      <td>Taste was not as expected.</td>
      <td>Customer Service</td>
      <td>Negative</td>
      <td>2024-08-06</td>
    </tr>
    <tr>
      <th>1718</th>
      <td>4210815</td>
      <td>3217749279</td>
      <td>40643232</td>
      <td>1</td>
      <td>Very disappointed with the quality.</td>
      <td>Customer Service</td>
      <td>Negative</td>
      <td>2023-09-29</td>
    </tr>
    <tr>
      <th>1720</th>
      <td>5483280</td>
      <td>222955546</td>
      <td>51661209</td>
      <td>1</td>
      <td>Customer service was not helpful.</td>
      <td>App Experience</td>
      <td>Negative</td>
      <td>2023-09-27</td>
    </tr>
    <tr>
      <th>1676</th>
      <td>6014791</td>
      <td>7146572423</td>
      <td>80954112</td>
      <td>1</td>
      <td>I had a bad experience.</td>
      <td>Product Quality</td>
      <td>Negative</td>
      <td>2023-06-01</td>
    </tr>
    <tr>
      <th>1680</th>
      <td>9712922</td>
      <td>5183577434</td>
      <td>2134827</td>
      <td>1</td>
      <td>Not worth the price I paid.</td>
      <td>Customer Service</td>
      <td>Negative</td>
      <td>2024-01-03</td>
    </tr>
    <tr>
      <th>1684</th>
      <td>4267888</td>
      <td>8997788831</td>
      <td>72495274</td>
      <td>1</td>
      <td>The packaging was poor.</td>
      <td>Delivery</td>
      <td>Negative</td>
      <td>2023-03-23</td>
    </tr>
    <tr>
      <th>1692</th>
      <td>364879</td>
      <td>2985254380</td>
      <td>73377004</td>
      <td>1</td>
      <td>Product was damaged during delivery.</td>
      <td>Product Quality</td>
      <td>Negative</td>
      <td>2023-11-04</td>
    </tr>
    <tr>
      <th>1695</th>
      <td>7470294</td>
      <td>8829163586</td>
      <td>11387110</td>
      <td>1</td>
      <td>Taste was not as expected.</td>
      <td>Product Quality</td>
      <td>Negative</td>
      <td>2024-01-16</td>
    </tr>
    <tr>
      <th>1697</th>
      <td>2440958</td>
      <td>5792721465</td>
      <td>49617892</td>
      <td>1</td>
      <td>I had a bad experience.</td>
      <td>Delivery</td>
      <td>Negative</td>
      <td>2024-10-18</td>
    </tr>
    <tr>
      <th>1708</th>
      <td>9066926</td>
      <td>4357632507</td>
      <td>6150721</td>
      <td>1</td>
      <td>I had a bad experience.</td>
      <td>Customer Service</td>
      <td>Negative</td>
      <td>2024-09-13</td>
    </tr>
    <tr>
      <th>1807</th>
      <td>3130596</td>
      <td>812386333</td>
      <td>72605638</td>
      <td>1</td>
      <td>Not worth the price I paid.</td>
      <td>Customer Service</td>
      <td>Negative</td>
      <td>2024-09-18</td>
    </tr>
    <tr>
      <th>1975</th>
      <td>3346882</td>
      <td>7736615348</td>
      <td>84161531</td>
      <td>1</td>
      <td>Items were missing from my order.</td>
      <td>Product Quality</td>
      <td>Negative</td>
      <td>2023-12-06</td>
    </tr>
    <tr>
      <th>1988</th>
      <td>1837680</td>
      <td>3329455953</td>
      <td>31371112</td>
      <td>1</td>
      <td>The order was incorrect.</td>
      <td>Delivery</td>
      <td>Negative</td>
      <td>2024-03-01</td>
    </tr>
    <tr>
      <th>1993</th>
      <td>3914733</td>
      <td>6799246060</td>
      <td>6245778</td>
      <td>1</td>
      <td>Delivery was late and I was unhappy.</td>
      <td>Delivery</td>
      <td>Negative</td>
      <td>2023-11-06</td>
    </tr>
    <tr>
      <th>1629</th>
      <td>5112150</td>
      <td>3228806806</td>
      <td>70543108</td>
      <td>1</td>
      <td>Very disappointed with the quality.</td>
      <td>Product Quality</td>
      <td>Negative</td>
      <td>2023-06-29</td>
    </tr>
  </tbody>
</table>
</div>



**10. Is there a link between negative feedback and specific products, delivery times, or order experience?**

 Join feedback with orders and delivery data.


```python
# Table Merged
cf_oi = pd.merge(customer_feedback, order_items[['order_id','product_id']], on = 'order_id', how = 'inner')
cf_oi_prod = pd.merge(cf_oi, products[['product_id', 'product_name', 'category']], on = 'product_id', how = 'left')
cf_oi_prod_dp = pd.merge(cf_oi_prod, delivery_performance[['order_id', 'delivery_partner_id', 'promised_time', 'actual_time', 'delivery_time_minutes', 'distance_km', 'delivery_status', 'reasons_if_delayed']], on = ['order_id'], how = 'inner')
cf_oi_prod_dp.head()

neg_fb = cf_oi_prod_dp[(cf_oi_prod_dp['sentiment'] == 'Negative') & 
        (cf_oi_prod_dp['product_name'].notna()) & 
        (cf_oi_prod_dp['delivery_time_minutes'].notna()) &
        (cf_oi_prod_dp['feedback_category'].notna()) &
        (cf_oi_prod_dp['feedback_text'].str.strip != '')]

neg_feedback = neg_fb[['sentiment','product_name','delivery_time_minutes','feedback_text']]

neg_feedback.head(10).sort_values(by = 'delivery_time_minutes', ascending = False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sentiment</th>
      <th>product_name</th>
      <th>delivery_time_minutes</th>
      <th>feedback_text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>16</th>
      <td>Negative</td>
      <td>Toothpaste</td>
      <td>13</td>
      <td>I had a bad experience.</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Negative</td>
      <td>Popcorn</td>
      <td>13</td>
      <td>Items were missing from my order.</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Negative</td>
      <td>Vitamins</td>
      <td>12</td>
      <td>Customer service was not helpful.</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Negative</td>
      <td>Toilet Cleaner</td>
      <td>12</td>
      <td>The order was incorrect.</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Negative</td>
      <td>Cough Syrup</td>
      <td>8</td>
      <td>Not worth the price I paid.</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Negative</td>
      <td>Lotion</td>
      <td>3</td>
      <td>Product was damaged during delivery.</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Negative</td>
      <td>Bread</td>
      <td>2</td>
      <td>I had a bad experience.</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Negative</td>
      <td>Orange Juice</td>
      <td>2</td>
      <td>The order was incorrect.</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Negative</td>
      <td>Baby Wipes</td>
      <td>2</td>
      <td>Product was damaged during delivery.</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Negative</td>
      <td>Nuts</td>
      <td>1</td>
      <td>Product was damaged during delivery.</td>
    </tr>
  </tbody>
</table>
</div>



**• Customer Insights & Segmentation**

**11. Which customer segments contribute the most to revenue and have the highest frequency of orders?**

 Use customer demographics + RFM (Recency, Frequency, Monetary) segmentation.


```python
oi_o.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>product_id</th>
      <th>quantity</th>
      <th>unit_price</th>
      <th>customer_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1961864118</td>
      <td>642612</td>
      <td>3</td>
      <td>517.03</td>
      <td>30065862</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1549769649</td>
      <td>378676</td>
      <td>1</td>
      <td>881.42</td>
      <td>9573071</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9185164487</td>
      <td>741341</td>
      <td>2</td>
      <td>923.84</td>
      <td>45477575</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9644738826</td>
      <td>561860</td>
      <td>1</td>
      <td>874.78</td>
      <td>88067569</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5427684290</td>
      <td>602241</td>
      <td>2</td>
      <td>976.55</td>
      <td>83298567</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
import numpy as  np

# table merged
oi_o = pd.merge(order_items, orders, on = 'order_id', how = 'inner')

# Time span for recency orders
reference_time = oi_o['order_date'].max() + pd.Timedelta(days = 1)

#  Calculate RFM
rfm = oi_o.groupby('customer_id').agg({
    'order_date' : lambda a: (reference_time - a.max()).days,
    'order_id' : 'count',
    'unit_price' : 'sum'}).rename(columns = {'order_date' : 'Recency', 'order_id':'Frequency', 'unit_price':'Monetary'})


# Labels score the RFM

def assign_series(series, ascending = True, bins = 5):
    #compute quantiles for bins edge
    quantiles = series.quantile(np.linspace(0,1, bins + 1)).unique()
    quantiles = np.sort(quantiles)

    labels = list(range(1, len(quantiles)))
    if not ascending:
        labels = labels[::-1]

    return pd.cut(series, bins= quantiles, labels = labels, include_lowest =True)

rfm['R_score'] = assign_series(rfm['Recency'], ascending = True, bins =5)
rfm['F_score'] = assign_series(rfm['Frequency'], ascending = False, bins =5)
rfm['M_score'] = assign_series(rfm['Monetary'], ascending = False, bins =5)

#Combine all score in a segment
rfm['RFM_segment'] =rfm['R_score'].astype('str') + rfm['F_score'].astype('str') + rfm['M_score'].astype('str')

# Merge RFM+ customers
customer_RFM = pd.merge(rfm, customers, on = 'customer_id', how = 'left')

# Analyse Customers
analyse_segment = customer_RFM.groupby(['customer_id','customer_segment','RFM_segment']).agg({'Frequency':'sum','Monetary':'sum'}).reset_index()
```


```python
rfm.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Recency</th>
      <th>Frequency</th>
      <th>Monetary</th>
      <th>R_score</th>
      <th>F_score</th>
      <th>M_score</th>
      <th>RFM_segment</th>
    </tr>
    <tr>
      <th>customer_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>31813</th>
      <td>26</td>
      <td>2</td>
      <td>1601.66</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>132</td>
    </tr>
    <tr>
      <th>61020</th>
      <td>66</td>
      <td>3</td>
      <td>2293.48</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>221</td>
    </tr>
    <tr>
      <th>119099</th>
      <td>165</td>
      <td>4</td>
      <td>1342.16</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>312</td>
    </tr>
    <tr>
      <th>188838</th>
      <td>260</td>
      <td>2</td>
      <td>1370.95</td>
      <td>4</td>
      <td>3</td>
      <td>2</td>
      <td>432</td>
    </tr>
    <tr>
      <th>191616</th>
      <td>165</td>
      <td>2</td>
      <td>1638.03</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>332</td>
    </tr>
    <tr>
      <th>211163</th>
      <td>149</td>
      <td>3</td>
      <td>937.37</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>323</td>
    </tr>
    <tr>
      <th>243838</th>
      <td>336</td>
      <td>3</td>
      <td>1012.92</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>423</td>
    </tr>
    <tr>
      <th>376144</th>
      <td>114</td>
      <td>5</td>
      <td>2664.64</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>211</td>
    </tr>
    <tr>
      <th>408590</th>
      <td>322</td>
      <td>1</td>
      <td>397.55</td>
      <td>4</td>
      <td>3</td>
      <td>5</td>
      <td>435</td>
    </tr>
    <tr>
      <th>469006</th>
      <td>162</td>
      <td>3</td>
      <td>1014.04</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>323</td>
    </tr>
  </tbody>
</table>
</div>




```python
analyse_segment.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>customer_segment</th>
      <th>RFM_segment</th>
      <th>Frequency</th>
      <th>Monetary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>31813</td>
      <td>Regular</td>
      <td>132</td>
      <td>2</td>
      <td>1601.66</td>
    </tr>
    <tr>
      <th>1</th>
      <td>61020</td>
      <td>New</td>
      <td>221</td>
      <td>3</td>
      <td>2293.48</td>
    </tr>
    <tr>
      <th>2</th>
      <td>119099</td>
      <td>Inactive</td>
      <td>312</td>
      <td>4</td>
      <td>1342.16</td>
    </tr>
    <tr>
      <th>3</th>
      <td>188838</td>
      <td>Inactive</td>
      <td>432</td>
      <td>2</td>
      <td>1370.95</td>
    </tr>
    <tr>
      <th>4</th>
      <td>191616</td>
      <td>Regular</td>
      <td>332</td>
      <td>2</td>
      <td>1638.03</td>
    </tr>
  </tbody>
</table>
</div>



**12. What are the differences in order behaviour across cities or PIN codes?**

 Geo map with filters for frequency, avg. basket size, and feedback score.


```python
customer_feedback.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>feedback_id</th>
      <th>order_id</th>
      <th>customer_id</th>
      <th>rating</th>
      <th>feedback_text</th>
      <th>feedback_category</th>
      <th>sentiment</th>
      <th>feedback_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2234710</td>
      <td>1961864118</td>
      <td>30065862</td>
      <td>4</td>
      <td>It was okay, nothing special.</td>
      <td>Delivery</td>
      <td>Neutral</td>
      <td>2024-07-17</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5450964</td>
      <td>1549769649</td>
      <td>9573071</td>
      <td>3</td>
      <td>The order was incorrect.</td>
      <td>App Experience</td>
      <td>Negative</td>
      <td>2024-05-28</td>
    </tr>
    <tr>
      <th>2</th>
      <td>482108</td>
      <td>9185164487</td>
      <td>45477575</td>
      <td>3</td>
      <td>It was okay, nothing special.</td>
      <td>App Experience</td>
      <td>Neutral</td>
      <td>2024-09-23</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4823104</td>
      <td>9644738826</td>
      <td>88067569</td>
      <td>4</td>
      <td>The product met my expectations.</td>
      <td>App Experience</td>
      <td>Neutral</td>
      <td>2023-11-24</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3537464</td>
      <td>5427684290</td>
      <td>83298567</td>
      <td>3</td>
      <td>Product was damaged during delivery.</td>
      <td>Delivery</td>
      <td>Negative</td>
      <td>2023-11-20</td>
    </tr>
  </tbody>
</table>
</div>




```python
# oi_o_c.head()
```


```python
# Merging order_items, orders and customers table
oi_o_c = pd.merge(oi_o[['order_id','product_id','customer_id','order_date']],customers[['customer_id','area','pincode','total_orders','avg_order_value']], on = 'customer_id', how = 'inner')
# New column for revenue
oi_o_c['Revenue'] = oi_o_c['total_orders'] * oi_o_c['avg_order_value']
# Joined Customer Feedback table
oi_o_c_cf = pd.merge(oi_o_c,customer_feedback, on =['order_id','customer_id'], how = 'left')

#Order behaviour across cities or PIN codes
order_behav = oi_o_c_cf.groupby(['area','pincode']).agg(Order_count =('order_id','count'),
                                                     Total_Revenue = ('Revenue','sum'),
                                                    Avg_basket_size=('Revenue','mean'),
                                                    Feedback_score = ('rating','mean')).reset_index()

order_behav_sorted = order_behav.round(2).sort_values(by ='Total_Revenue', ascending = False). head(10)
order_behav_sorted
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>area</th>
      <th>pincode</th>
      <th>Order_count</th>
      <th>Total_Revenue</th>
      <th>Avg_basket_size</th>
      <th>Feedback_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1090</th>
      <td>Karimnagar</td>
      <td>638908</td>
      <td>7</td>
      <td>197525.72</td>
      <td>28217.96</td>
      <td>3.29</td>
    </tr>
    <tr>
      <th>1537</th>
      <td>Ongole</td>
      <td>989821</td>
      <td>6</td>
      <td>178796.82</td>
      <td>29799.47</td>
      <td>3.33</td>
    </tr>
    <tr>
      <th>1886</th>
      <td>Sikar</td>
      <td>555117</td>
      <td>5</td>
      <td>175074.00</td>
      <td>35014.80</td>
      <td>3.80</td>
    </tr>
    <tr>
      <th>1447</th>
      <td>Nanded</td>
      <td>425857</td>
      <td>5</td>
      <td>162804.60</td>
      <td>32560.92</td>
      <td>3.20</td>
    </tr>
    <tr>
      <th>1781</th>
      <td>Saharanpur</td>
      <td>260071</td>
      <td>4</td>
      <td>151701.60</td>
      <td>37925.40</td>
      <td>3.25</td>
    </tr>
    <tr>
      <th>1012</th>
      <td>Jorhat</td>
      <td>23557</td>
      <td>6</td>
      <td>146896.20</td>
      <td>24482.70</td>
      <td>3.33</td>
    </tr>
    <tr>
      <th>1987</th>
      <td>Tezpur</td>
      <td>49861</td>
      <td>5</td>
      <td>145410.75</td>
      <td>29082.15</td>
      <td>3.60</td>
    </tr>
    <tr>
      <th>2027</th>
      <td>Thoothukudi</td>
      <td>796020</td>
      <td>4</td>
      <td>144981.60</td>
      <td>36245.40</td>
      <td>3.25</td>
    </tr>
    <tr>
      <th>1289</th>
      <td>Mahbubnagar</td>
      <td>251772</td>
      <td>7</td>
      <td>144892.44</td>
      <td>20698.92</td>
      <td>2.71</td>
    </tr>
    <tr>
      <th>364</th>
      <td>Bhopal</td>
      <td>402853</td>
      <td>5</td>
      <td>144353.60</td>
      <td>28870.72</td>
      <td>4.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig = plt.figure(figsize=(22,14))
gs = plt.GridSpec(2,4)


# PLot 1 Horizontal Bar
ax1 = plt.subplot(gs[0, :2])
sns.barplot(data = order_behav_sorted, x='pincode', y='Order_count', palette='pastel', edgecolor= 'k', linewidth = 2)

ax1.set_title('Order count by Area Pincode', fontweight='bold', fontsize=14)
ax1.set_xlabel('Area Pincode', fontweight = "bold", fontsize = 10)
ax1.set_ylabel('Order Count', fontweight = "bold", fontsize = 10)


# PLot 2 PIE
ax2 = plt.subplot(gs[1,:2])
sns.barplot(data = order_behav_sorted.sort_values(by = 'Total_Revenue', ascending = True), x='pincode', y='Total_Revenue', palette='viridis', edgecolor = 'k')
ax2.set_xlabel('Area Pincode', fontweight = "bold", fontsize = 10)
ax2.set_ylabel('Total Revenue', fontweight = "bold", fontsize = 10)


# Scatter Plot: Avg Basket Size vs Feedback Score
ax3 = plt.subplot(gs[:, 2:])
sns.scatterplot(data = order_behav_sorted, x='Avg_basket_size', y='Feedback_score', size = 'Order_count' , sizes = (40,400), edgecolor = 'k', s = 50, linewidth = 1, color = 'r')

ax3.set_title('Average Basket Size vs Feedback Score by Area/Pincode', fontweight='bold', fontsize=14)
ax3.set_xlabel('Average Basket Size ', fontweight = "bold", fontsize = 10)
ax3.set_ylabel('Average Feedback Rating', fontweight = "bold", fontsize = 10)
ax3.grid()
ax3.legend(title = "Order Count", fontsize = 18)


plt.tight_layout()
plt.show()
```


    
![png](output_62_0.png)
    


**13. What patterns exist in customer ordering times (day of week, hour of day)?**



```python
# Make a columns of 'weekday' and 'hour'
oi_o_c['Day_Of_Week'] = oi_o_c['order_date'].dt.weekday
oi_o_c['Hour_Of_Day'] = oi_o_c['order_date'].dt.hour

ordering_time = oi_o_c.groupby('customer_id').agg(
    Mean_Day_OfWeek=('Day_Of_Week', 'mean'),
    Mode_Day_OfWeek=('Day_Of_Week', lambda x: x.mode().iloc[0] if not x.mode().empty else None),
    Mean_Hour_OfDay=('Hour_Of_Day', 'mean'),
    Mode_Hour_OfDay=('Hour_Of_Day', lambda x: x.mode().iloc[0] if not x.mode().empty else None)
)
ordering_time.round(3).head(10).reset_index()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>Mean_Day_OfWeek</th>
      <th>Mode_Day_OfWeek</th>
      <th>Mean_Hour_OfDay</th>
      <th>Mode_Hour_OfDay</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>31813</td>
      <td>3.000</td>
      <td>3</td>
      <td>8.000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>61020</td>
      <td>4.333</td>
      <td>2</td>
      <td>15.000</td>
      <td>14</td>
    </tr>
    <tr>
      <th>2</th>
      <td>119099</td>
      <td>4.000</td>
      <td>4</td>
      <td>9.750</td>
      <td>4</td>
    </tr>
    <tr>
      <th>3</th>
      <td>188838</td>
      <td>0.500</td>
      <td>0</td>
      <td>9.000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>191616</td>
      <td>2.000</td>
      <td>0</td>
      <td>5.000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>5</th>
      <td>211163</td>
      <td>5.000</td>
      <td>4</td>
      <td>14.667</td>
      <td>10</td>
    </tr>
    <tr>
      <th>6</th>
      <td>243838</td>
      <td>1.667</td>
      <td>1</td>
      <td>15.000</td>
      <td>10</td>
    </tr>
    <tr>
      <th>7</th>
      <td>376144</td>
      <td>3.600</td>
      <td>6</td>
      <td>6.800</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>408590</td>
      <td>1.000</td>
      <td>1</td>
      <td>16.000</td>
      <td>16</td>
    </tr>
    <tr>
      <th>9</th>
      <td>469006</td>
      <td>3.333</td>
      <td>5</td>
      <td>8.333</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
#
# Count the orders per ( hour/ week)
heat_map = oi_o_c.pivot_table(values = "customer_id",
                              index = "Hour_Of_Day",
                              columns = "Day_Of_Week",
                              aggfunc = "count")

# plot week days
day_labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
heat_map.columns = day_labels[:heat_map.shape[1]]

# Visualization
plt.figure(figsize=(10,6))
sns.heatmap(heat_map, annot = True, cmap = 'coolwarm_r', fmt = 'd', linewidth = 0.5)
plt.title('Order Frequency Heatmap: Hour vs Day', fontweight = "bold", fontsize = 13)
plt.xlabel('Day of Week', fontweight = "bold")
plt.ylabel('Hour of Day', fontweight = "bold")
plt.tight_layout()
plt.show()


print("\n")
print("                               Analysis Volume of customer's order in Week as well as Time")
```


    
![png](output_65_0.png)
    


    
    
                                   Analysis Volume of customer's order in Week as well as Time
    

**• Order Patterns & Trends** 

**14. Which product categories drive the most revenue vs. volume?**



```python
# oi_o_c = pd.merge(oi_o[['order_id','product_id','customer_id']],customers[['customer_id','area','pincode','total_orders','avg_order_value','Revenue']], on = 'customer_id', how = 'inner')
# oi_o_c.drop(columns = ['Day_Of_Week','Hour_Of_Day'], inplace = True)

# Add column revenue by quantity * price
oi_o_p['Revenue'] = oi_o_p['quantity'] * oi_o_p['unit_price']

# Group by category to compare volume vs Revenue
prod_cat = oi_o_p.groupby('category').agg(Volume = ('product_id','count'),
                                            Revenue = ('Revenue','sum')).sort_values(by = 'Volume', ascending = False).reset_index()
prod_cat
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>category</th>
      <th>Volume</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Dairy &amp; Breakfast</td>
      <td>566</td>
      <td>639222.19</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Household Care</td>
      <td>509</td>
      <td>444244.25</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Pet Care</td>
      <td>501</td>
      <td>539888.75</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Fruits &amp; Vegetables</td>
      <td>492</td>
      <td>559053.08</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Snacks &amp; Munchies</td>
      <td>483</td>
      <td>394648.71</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Pharmacy</td>
      <td>481</td>
      <td>592368.57</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Personal Care</td>
      <td>454</td>
      <td>394894.61</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Grocery &amp; Staples</td>
      <td>449</td>
      <td>359937.82</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Cold Drinks &amp; Juices</td>
      <td>375</td>
      <td>392717.62</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Instant &amp; Frozen Food</td>
      <td>356</td>
      <td>307212.65</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Baby Care</td>
      <td>334</td>
      <td>348227.18</td>
    </tr>
  </tbody>
</table>
</div>




```python
# prod_cat = prod_cat.reset_index()

plt.figure(figsize = (10,8))

# colors = ['#bc0c1c'] + ['steelblue'] * 10
sns.barplot(data =prod_cat,  y= prod_cat['category'], x = prod_cat['Revenue'], hue = prod_cat['Volume'],palette = 'coolwarm_r', edgecolor = 'k', linewidth = 2)

plt.title('Revenue vs. Volume By Product Category', fontweight='bold', fontsize=14)
plt.xlabel('Product Category', fontweight='bold')
plt.ylabel('Revenue', fontweight='bold')
plt.legend(title = 'Order Volume', fontsize = 10)

plt.tight_layout()
plt.show()

```


    
![png](output_68_0.png)
    


**15. What is the average order value (AOV) trend over time and how does it vary by city or customer type?**


```python
# Merging Table by inner join
o_oi = pd.merge(orders[['order_id','customer_id','order_date','delivery_status','order_total','payment_method','delivery_partner_id','order_hour',]], order_items , on = 'order_id', how = 'inner')
o_oi_c = pd.merge(o_oi, customers , on = 'customer_id', how = 'inner')


# Add new column of revenue
o_oi_c['Revenue'] = o_oi_c['quantity'] * o_oi_c['unit_price']

#total revenue by 'order_id','area','customer_segment','order_date'
order_reve = o_oi_c.groupby(['order_id','area','customer_segment','order_date']).agg(Order_Revenue =('Revenue','sum')).reset_index()

# Extract order_date in 'month year'
order_reve['Year_Month'] = order_reve['order_date'].dt.to_period('M')

# Find avg of average order value
AOV = order_reve.groupby(['area','customer_segment','Year_Month']).agg(Avg_Order_Revenue = ('Order_Revenue','mean')).sort_values(by = 'Avg_Order_Revenue', ascending = False).reset_index()
AOV = AOV.head(15)                         
AOV
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>area</th>
      <th>customer_segment</th>
      <th>Year_Month</th>
      <th>Avg_Order_Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Nizamabad</td>
      <td>Regular</td>
      <td>2023-04</td>
      <td>2987.94</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Jamshedpur</td>
      <td>Premium</td>
      <td>2024-03</td>
      <td>2987.94</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bareilly</td>
      <td>Inactive</td>
      <td>2024-03</td>
      <td>2987.94</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Jalna</td>
      <td>New</td>
      <td>2024-07</td>
      <td>2987.94</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Madurai</td>
      <td>Regular</td>
      <td>2024-04</td>
      <td>2987.94</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Shivpuri</td>
      <td>Premium</td>
      <td>2024-03</td>
      <td>2983.68</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Allahabad</td>
      <td>Regular</td>
      <td>2024-05</td>
      <td>2983.68</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Gandhinagar</td>
      <td>Regular</td>
      <td>2023-04</td>
      <td>2983.68</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Jamalpur</td>
      <td>New</td>
      <td>2024-01</td>
      <td>2983.68</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Guwahati</td>
      <td>Premium</td>
      <td>2023-10</td>
      <td>2983.68</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Bijapur</td>
      <td>New</td>
      <td>2024-03</td>
      <td>2983.68</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Anantapuram</td>
      <td>Inactive</td>
      <td>2024-02</td>
      <td>2983.68</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Raiganj</td>
      <td>New</td>
      <td>2023-06</td>
      <td>2969.64</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Bilaspur</td>
      <td>Regular</td>
      <td>2024-10</td>
      <td>2969.64</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Guntakal</td>
      <td>Regular</td>
      <td>2023-10</td>
      <td>2969.64</td>
    </tr>
  </tbody>
</table>
</div>




```python
AOV.dtypes
```




    area                    object
    customer_segment        object
    Year_Month           period[M]
    Avg_Order_Revenue      float64
    dtype: object




```python
AOV['Year_Month'] = AOV['Year_Month'].astype('datetime64[ns]')
plt.figure(figsize = (14,8))
sns.lineplot(data = AOV, x = AOV['Year_Month'], y = AOV['Avg_Order_Revenue'],
             style = "customer_segment",
             markers = True,
             linewidth = 2,
             hue = 'customer_segment',
             dashes = False)

plt.title('Average Order Value (AOV) Trend Over Time by Customer Segment', fontsize=16, fontweight='bold')
plt.xlabel('Year-Month', fontsize=14)
plt.ylabel('Average Order Revenue', fontsize=14)
plt.xticks(rotation=45)
plt.legend(title = "Customer Segment")

plt.tight_layout()
plt.show()

```


    
![png](output_72_0.png)
    


**16. Identify top 10 fastmoving and slow-moving products based on sales and delivery turnaround time**


```python
# Table merged of order_items, oreders and products
o_oi = pd.merge(orders[['order_id','customer_id','order_date','actual_delivery_time','delivery_status','order_total','payment_method','delivery_partner_id','order_hour',]], order_items , on = 'order_id', how = 'inner')
o_oi_p = pd.merge(o_oi, products , on = 'product_id', how = 'inner')

# Column for revenue
o_oi_p['Revenue'] = o_oi_p['quantity'] * o_oi_p['unit_price']

# added column as Delivery_Time_days
o_oi_p['Delivery_Time_days'] = o_oi_p['order_date'] - o_oi_p['actual_delivery_time']

top10 = o_oi_p.groupby('product_name').agg(Sales = ('Revenue','sum'),
                                          Avg_Delivery_Time = ('Delivery_Time_days','mean')).reset_index()

# Top 10 Fastmoving Products
top10_fast = top10.sort_values(by = 'Avg_Delivery_Time', ascending = False).round(1).head(10).reset_index(drop = True)


# Top 10 Slowmoving Products
top10_slow = top10.sort_values(by = 'Avg_Delivery_Time', ascending = True).round(2).head(10).reset_index(drop = True)


print("Top 10 Fast moving Products\n")
top10_fast
```

    Top 10 Fast moving Products
    
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_name</th>
      <th>Sales</th>
      <th>Avg_Delivery_Time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Cereal</td>
      <td>24021.8</td>
      <td>-1 days +23:43:10.909090910</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Butter</td>
      <td>106843.3</td>
      <td>-1 days +23:42:17.260273973</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Frozen Pizza</td>
      <td>47783.3</td>
      <td>-1 days +23:42:06.136363637</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Cola</td>
      <td>132367.4</td>
      <td>-1 days +23:42:03.716814160</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Tomatoes</td>
      <td>44812.7</td>
      <td>-1 days +23:41:55.384615385</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Instant Noodles</td>
      <td>32801.6</td>
      <td>-1 days +23:41:54.857142858</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Iced Tea</td>
      <td>71171.2</td>
      <td>-1 days +23:41:45</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Milk</td>
      <td>33534.5</td>
      <td>-1 days +23:41:34.285714286</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Spinach</td>
      <td>25233.6</td>
      <td>-1 days +23:41:31.428571429</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Frozen Vegetables</td>
      <td>59165.6</td>
      <td>-1 days +23:41:26.865671642</td>
    </tr>
  </tbody>
</table>
</div>




```python
print("\n\nTop 10 slow moving Products\n")
top10_slow
```

    
    
    Top 10 slow moving Products
    
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_name</th>
      <th>Sales</th>
      <th>Avg_Delivery_Time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Ice Cream</td>
      <td>55899.99</td>
      <td>-1 days +23:36:38.400000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Lemonade</td>
      <td>14977.80</td>
      <td>-1 days +23:37:11.428571429</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Diapers</td>
      <td>52015.98</td>
      <td>-1 days +23:37:37.674418605</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Nuts</td>
      <td>67024.13</td>
      <td>-1 days +23:39:25.714285715</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Onions</td>
      <td>138858.42</td>
      <td>-1 days +23:39:26.250000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Potatoes</td>
      <td>92859.84</td>
      <td>-1 days +23:39:32.389380531</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Shampoo</td>
      <td>49675.89</td>
      <td>-1 days +23:39:36.750000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Cheese</td>
      <td>78519.56</td>
      <td>-1 days +23:39:36.976744187</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Rice</td>
      <td>22524.08</td>
      <td>-1 days +23:39:43.018867925</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Chocolates</td>
      <td>49619.92</td>
      <td>-1 days +23:39:43.125000</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

**17. Which cities or zones experience the highest delivery delays?**


```python
# Table Merged
c_o = pd.merge(customers[['customer_id','area','customer_segment','total_orders','avg_order_value']],orders[['order_id','customer_id','order_date','order_total','order_hour']], on = 'customer_id', how = 'inner')
c_o_dp = pd.merge(c_o,delivery_performance, on = 'order_id', how = 'inner')
        
# zones experience the highest delivery delays
delay = c_o_dp[c_o_dp['delivery_time_minutes'] > 0]
zones = delay.groupby('area').agg(Delay_in_Minutes = ('delivery_time_minutes','sum')).sort_values(by = 'Delay_in_Minutes', ascending = False)
zones.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Delay_in_Minutes</th>
    </tr>
    <tr>
      <th>area</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Orai</th>
      <td>294</td>
    </tr>
    <tr>
      <th>Gandhinagar</th>
      <td>225</td>
    </tr>
    <tr>
      <th>Ghaziabad</th>
      <td>223</td>
    </tr>
    <tr>
      <th>Agra</th>
      <td>221</td>
    </tr>
    <tr>
      <th>Etawah</th>
      <td>205</td>
    </tr>
    <tr>
      <th>Thoothukudi</th>
      <td>201</td>
    </tr>
    <tr>
      <th>Bathinda</th>
      <td>193</td>
    </tr>
    <tr>
      <th>Deoghar</th>
      <td>186</td>
    </tr>
    <tr>
      <th>Udaipur</th>
      <td>184</td>
    </tr>
    <tr>
      <th>Bangalore</th>
      <td>180</td>
    </tr>
  </tbody>
</table>
</div>




```python

zones_sorted = zones.sort_values(by='Delay_in_Minutes', ascending=False).head(10)

# Calculate cumulative sum and cumulative percentage
zones_sorted['Cumulative_Sum'] = zones_sorted['Delay_in_Minutes'].cumsum()
zones_sorted['Cumulative_Percent'] = 100 * zones_sorted['Cumulative_Sum'] / zones_sorted['Delay_in_Minutes'].sum()

# Plot
fig, ax1 = plt.subplots(figsize=(12, 6))

# Bar plot
ax1.bar(zones_sorted.index, zones_sorted['Delay_in_Minutes'], color='skyblue')
ax1.set_xlabel('Zone (Area)')
ax1.set_ylabel('Total Delay Minutes', color='blue')
ax1.tick_params(axis='y', labelcolor='blue')
plt.xticks(rotation=45)

# Line plot
ax2 = ax1.twinx()
ax2.plot(zones_sorted.index, zones_sorted['Cumulative_Percent'], color='red', marker='o', linestyle='-', linewidth=2)
ax2.set_ylabel('Cumulative Percentage (%)', color='red')
ax2.tick_params(axis='y', labelcolor='red')
ax2.set_ylim(0, 110)

plt.title('Delivery Delay by Zones')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

```


    
![png](output_79_0.png)
    



```python
zones_sorted
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Delay_in_Minutes</th>
      <th>Cumulative_Sum</th>
      <th>Cumulative_Percent</th>
    </tr>
    <tr>
      <th>area</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Orai</th>
      <td>294</td>
      <td>294</td>
      <td>13.920455</td>
    </tr>
    <tr>
      <th>Gandhinagar</th>
      <td>225</td>
      <td>519</td>
      <td>24.573864</td>
    </tr>
    <tr>
      <th>Ghaziabad</th>
      <td>223</td>
      <td>742</td>
      <td>35.132576</td>
    </tr>
    <tr>
      <th>Agra</th>
      <td>221</td>
      <td>963</td>
      <td>45.596591</td>
    </tr>
    <tr>
      <th>Etawah</th>
      <td>205</td>
      <td>1168</td>
      <td>55.303030</td>
    </tr>
    <tr>
      <th>Thoothukudi</th>
      <td>201</td>
      <td>1369</td>
      <td>64.820076</td>
    </tr>
    <tr>
      <th>Bathinda</th>
      <td>193</td>
      <td>1562</td>
      <td>73.958333</td>
    </tr>
    <tr>
      <th>Deoghar</th>
      <td>186</td>
      <td>1748</td>
      <td>82.765152</td>
    </tr>
    <tr>
      <th>Udaipur</th>
      <td>184</td>
      <td>1932</td>
      <td>91.477273</td>
    </tr>
    <tr>
      <th>Bangalore</th>
      <td>180</td>
      <td>2112</td>
      <td>100.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
